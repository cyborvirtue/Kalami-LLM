<?php
namespace ntest;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of p1
 *
 * @author yftkwyp
 */
class p1 {
    public function __construct() {
        echo 1;
    }
    
    protected  function t(){
        echo 2;
    }
}
