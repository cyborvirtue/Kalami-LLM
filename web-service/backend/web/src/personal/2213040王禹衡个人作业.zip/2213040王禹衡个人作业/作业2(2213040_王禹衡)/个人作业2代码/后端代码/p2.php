<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace ntest;

/**
 * Description of p2
 *
 * @author yftkwyp
 */
class p2 extends p1 {
    //put your code here
}

$px = new p2();
$px->t();


echo 1;